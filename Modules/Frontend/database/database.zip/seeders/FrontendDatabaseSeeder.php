<?php

namespace Modules\Frontend\database\seeders;

use Illuminate\Database\Seeder;

class FrontendDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {

        // Product::factory()->count(150)->create();
    }
}
